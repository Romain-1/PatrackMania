#pragma once

using Texture = unsigned int;

