#pragma once

#include <GL/glcorearb.h>

struct VertexHandlers
{
	GLuint vao;
	GLuint ibo;
	GLuint vbo[3];
	GLuint textureId;
};
