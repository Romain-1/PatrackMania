#pragma once

#include <cyclone.h>

class main
{
};